import React, { useState } from "react";

const data = {
  Futbol: [
    { name: "Lionel Messi", club: "Barcelona", nationality: "Argentina", bio: "Considerado uno de los mejores jugadores de todos los tiempos." },
    { name: "Cristiano Ronaldo", club: "Real Madrid", nationality: "Portugal", bio: "Delantero histórico con múltiples balones de oro." },
    { name: "Antoine Griezmann", club: "Atlético Madrid", nationality: "Francia", bio: "Delantero creativo y campeón del mundo." },
    { name: "Wayne Rooney", club: "Manchester United", nationality: "Inglaterra", bio: "Goleador histórico del Manchester United." },
    { name: "Frank Lampard", club: "Chelsea", nationality: "Inglaterra", bio: "Mediocampista icónico y leyenda del Chelsea." },
    { name: "Sergio 'Kun' Agüero", club: "Manchester City", nationality: "Argentina", bio: "Uno de los mejores delanteros de la Premier League." },
    { name: "Harry Kane & Son Heung-Min", club: "Tottenham", nationality: "Inglaterra / Corea del Sur", bio: "Dúo letal en ataque del Tottenham." },
    { name: "Steven Gerrard", club: "Liverpool", nationality: "Inglaterra", bio: "Capitán legendario del Liverpool." },
    { name: "Thierry Henry", club: "Arsenal", nationality: "Francia", bio: "Delantero estrella del Arsenal." },
    { name: "Javier Zanetti", club: "Inter", nationality: "Argentina", bio: "Capitán histórico del Inter de Milán." },
    { name: "Paolo Maldini", club: "Milan", nationality: "Italia", bio: "Defensor icónico del AC Milan." },
    { name: "Diego Maradona", club: "Napoli", nationality: "Argentina", bio: "Considerado uno de los más grandes de la historia." },
    { name: "Alessandro Del Piero", club: "Juventus", nationality: "Italia", bio: "Leyenda de la Juventus." },
    { name: "Gerd Müller", club: "Bayern", nationality: "Alemania", bio: "Goleador histórico del fútbol alemán." },
    { name: "Marco Reus", club: "Borussia Dortmund", nationality: "Alemania", bio: "Figura del Borussia Dortmund." },
    { name: "Kylian Mbappé", club: "PSG", nationality: "Francia", bio: "Estrella joven y campeón del mundo." },
  ],
  Voley: [
    { name: "Luciano De Cecco", nationality: "Argentina", bio: "Armador argentino destacado a nivel mundial." },
    { name: "Agustín Loser", nationality: "Argentina", bio: "Central argentino de la selección nacional." },
    { name: "Germán Gómez", nationality: "Argentina", bio: "Jugador importante de la selección argentina." },
    { name: "Facundo Conte", nationality: "Argentina", bio: "Receptor punta con gran trayectoria internacional." },
    { name: "Bruno Lima", nationality: "Argentina", bio: "Opuesto goleador de Argentina." },
    { name: "Antoine Brizard", nationality: "Francia", bio: "Armador de la selección francesa." },
    { name: "Simeon Nikolov", nationality: "Bulgaria", bio: "Central búlgaro de gran potencial." },
    { name: "Tobias Krick", nationality: "Alemania", bio: "Jugador joven y prometedor." },
    { name: "Yuji Nishida", nationality: "Japón", bio: "Opuesto japonés muy habilidoso." },
    { name: "Tomohiro Yamamoto", nationality: "Japón", bio: "Líbero de la selección japonesa." },
    { name: "Giba", nationality: "Brasil", bio: "Leyenda del vóley brasileño." },
    { name: "Darlan Souza", nationality: "Brasil", bio: "Jugador ofensivo de la selección brasileña." },
    { name: "Wilfredo León", nationality: "Cuba/Polonia", bio: "Uno de los mejores atacantes del mundo." },
    { name: "Alessandro Michieletto", nationality: "Italia", bio: "Joven estrella del vóley italiano." },
  ],
  Deportes: [
    { name: "LeBron James", sport: "Basket", nationality: "EE.UU.", bio: "Uno de los mejores jugadores de la NBA." },
    { name: "Kobe Bryant", sport: "Basket", nationality: "EE.UU.", bio: "Leyenda de los Lakers." },
    { name: "Michael Jordan", sport: "Basket", nationality: "EE.UU.", bio: "Considerado el mejor jugador de todos los tiempos." },
    { name: "Shaquille O'Neal", sport: "Basket", nationality: "EE.UU.", bio: "Dominante pívot de la NBA." },
    { name: "Stephen Curry", sport: "Basket", nationality: "EE.UU.", bio: "Revolucionó el baloncesto con el tiro de tres." },
    { name: "Kevin Durant", sport: "Basket", nationality: "EE.UU.", bio: "Gran anotador y campeón NBA." },
    { name: "Tim Duncan", sport: "Basket", nationality: "EE.UU.", bio: "El mejor ala-pívot de todos los tiempos." },
    { name: "Manu Ginóbili", sport: "Basket", nationality: "Argentina", bio: "Leyenda argentina en la NBA." },
    { name: "Max Verstappen", sport: "F1", nationality: "Países Bajos", bio: "Múltiple campeón de Fórmula 1." },
    { name: "Charles Leclerc", sport: "F1", nationality: "Mónaco", bio: "Joven estrella de Ferrari." },
    { name: "Lewis Hamilton", sport: "F1", nationality: "Reino Unido", bio: "Múltiple campeón mundial de F1." },
    { name: "Fernando Alonso", sport: "F1", nationality: "España", bio: "Campeón mundial con Renault." },
    { name: "Muhammad Ali", sport: "Box", nationality: "EE.UU.", bio: "El más grande boxeador de todos los tiempos." },
    { name: "Mike Tyson", sport: "Box", nationality: "EE.UU.", bio: "Campeón mundial y figura histórica del boxeo." },
  ],
  Videojuegos: [
    { name: "Mario", franchise: "Super Mario", bio: "El fontanero más famoso de los videojuegos." },
    { name: "Link", franchise: "The Legend of Zelda", bio: "Héroe de Hyrule." },
    { name: "Sonic", franchise: "Sonic the Hedgehog", bio: "Erizo azul supersónico." },
    { name: "Kirby", franchise: "Kirby", bio: "Pequeña bola rosa con gran poder." },
    { name: "Steve", franchise: "Minecraft", bio: "Personaje principal del juego sandbox más famoso." },
    { name: "Bacon", franchise: "Roblox", bio: "Personaje característico de Roblox." },
    { name: "Sans", franchise: "Undertale", bio: "Esqueleto carismático de Undertale." },
    { name: "Frisk", franchise: "Undertale", bio: "Protagonista de Undertale." },
    { name: "Larry", franchise: "Clash Royale", bio: "Esqueleto clásico del universo Clash." },
    { name: "Spike", franchise: "Brawl Stars", bio: "Cacto explosivo de Brawl Stars." },
    { name: "Cuphead", franchise: "Cuphead", bio: "Personaje principal con estilo retro." },
    { name: "Master Chief", franchise: "Halo", bio: "Protagonista de la saga Halo." },
    { name: "Lara Croft", franchise: "Tomb Raider", bio: "Aventurera icónica de los videojuegos." },
    { name: "Leon Kennedy", franchise: "Resident Evil", bio: "Policía y agente especial en Resident Evil." },
    { name: "Cloud Strife", franchise: "Final Fantasy VII", bio: "Héroe de Final Fantasy." },
    { name: "Captain Price", franchise: "Call of Duty", bio: "Soldado icónico de la saga CoD." },
    { name: "The Knight", franchise: "Hollow Knight", bio: "Protagonista del juego indie Hollow Knight." },
    { name: "Ezio Auditore", franchise: "Assassin’s Creed", bio: "Asesino más famoso de la saga AC." },
    { name: "William Afton", franchise: "FNAF", bio: "Villano de Five Nights at Freddy’s." },
  ],
  Cantantes: [
    { name: "Duki", nationality: "Argentina", bio: "Uno de los máximos exponentes del trap argentino." },
    { name: "Nicki Nicole", nationality: "Argentina", bio: "Cantante y rapera reconocida internacionalmente." },
    { name: "Milo J", nationality: "Argentina", bio: "Artista emergente del género urbano." },
    { name: "Bad Bunny", nationality: "Puerto Rico", bio: "Cantante global del reggaetón y trap." },
    { name: "Bizarrap", nationality: "Argentina", bio: "Productor musical famoso por sus Music Sessions." },
    { name: "Emilia Mernes", nationality: "Argentina", bio: "Cantante pop urbana." },
    { name: "Thiago PZK", nationality: "Argentina", bio: "Joven cantante urbano con proyección internacional." },
    { name: "Airbag", nationality: "Argentina", bio: "Banda de rock argentina." },
    { name: "Redimi2", nationality: "República Dominicana", bio: "Rapero cristiano reconocido." },
    { name: "Billie Eilish", nationality: "EE.UU.", bio: "Cantautora internacional ganadora de premios Grammy." },
    { name: "Taylor Swift", nationality: "EE.UU.", bio: "Cantautora global y multipremiada." },
    { name: "Trueno", nationality: "Argentina", bio: "Freestyler y rapero argentino." },
    { name: "Daddy Yankee", nationality: "Puerto Rico", bio: "Pionero del reggaetón." },
    { name: "Stray Kids", nationality: "Corea del Sur", bio: "Banda de K-pop de fama internacional." },
  ],
  Legendarias: [
    { name: "Messi (Campeón del Mundo)", bio: "Messi levantando la Copa del Mundo 2022." },
    { name: "Kobe Bryant (Campeón NBA)", bio: "Kobe en su máximo esplendor con los Lakers." },
    { name: "Michael Jackson", bio: "Rey del Pop y figura legendaria de la música." },
    { name: "Super Smash Bros", bio: "Franquicia icónica que reúne a múltiples personajes." },
  ],
};

export default function App() {
  const [category, setCategory] = useState(null);
  const [selected, setSelected] = useState(null);

  const categories = Object.keys(data);

  return (
    <div className="flex h-screen font-sans">
      {/* Sidebar */}
      <div className="w-1/4 bg-gray-900 text-white p-4">
        <h1 className="text-2xl font-bold mb-4">Miniverse</h1>
        <h2 className="text-sm italic mb-6">Colecciona lo que te apasiona</h2>
        <ul>
          {categories.map((cat) => (
            <li
              key={cat}
              className={`cursor-pointer mb-2 p-2 rounded ${
                category === cat ? "bg-gray-700" : "hover:bg-gray-800"
              }`}
              onClick={() => {
                setCategory(cat);
                setSelected(null);
              }}
            >
              {cat}
            </li>
          ))}
        </ul>
      </div>

      {/* Main content */}
      <div className="flex-1 p-6 overflow-y-auto">
        {!category && <p>Selecciona una categoría para empezar.</p>}

        {category && !selected && (
          <div>
            <h2 className="text-xl font-bold mb-4">{category}</h2>
            <ul className="grid grid-cols-2 gap-4">
              {data[category].map((item, idx) => (
                <li
                  key={idx}
                  className="p-4 bg-gray-100 rounded shadow cursor-pointer hover:bg-gray-200"
                  onClick={() => setSelected(item)}
                >
                  {item.name}
                </li>
              ))}
            </ul>
          </div>
        )}

        {selected && (
          <div className="p-6 bg-white rounded shadow">
            <button
              onClick={() => setSelected(null)}
              className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
            >
              ← Volver
            </button>
            <h2 className="text-2xl font-bold mb-2">{selected.name}</h2>
            {selected.club && <p><b>Club:</b> {selected.club}</p>}
            {selected.sport && <p><b>Deporte:</b> {selected.sport}</p>}
            {selected.franchise && <p><b>Franquicia:</b> {selected.franchise}</p>}
            {selected.nationality && <p><b>Nacionalidad:</b> {selected.nationality}</p>}
            <p className="mt-2">{selected.bio}</p>
          </div>
        )}
      </div>
    </div>
  );
}
